void main() {
  int age = 20; // استبدل 20 بعمرك الفعلي
  String message = (age >= 13 && age <= 19) ? "مراهق" : "ليس مراهقًا";
  print(message);
}
