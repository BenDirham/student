import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

// تطبيق Flutter الرئيسي
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dual FAB Counter',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const CounterScreen(),
    );
  }
}

// الشاشة الرئيسية مع StatefulWidget لإدارة الحالة
class CounterScreen extends StatefulWidget {
  const CounterScreen({super.key});

  @override
  State<CounterScreen> createState() => _CounterScreenState();
}

class _CounterScreenState extends State<CounterScreen> {
  int _counter = 0;

  // دالة لزيادة العداد
  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  // دالة لتقليل العداد
  void _decrementCounter() {
    setState(() {
      _counter--;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('عداد باستخدام زرين'),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // عرض العداد في المنتصف
            Text(
              '$_counter',
              style: const TextStyle(fontSize: 48),
            ),
            const SizedBox(height: 40), // مسافة بين العداد والأزرار
            // أزرار الزيادة والنقص في المنتصف
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FloatingActionButton(
                  onPressed: _incrementCounter,
                  tooltip: 'زيادة',
                  backgroundColor: Colors.green, // اللون الأخضر لزر الزيادة
                  child: const Icon(Icons.add),
                ),
                const SizedBox(width: 16),
                FloatingActionButton(
                  onPressed: _decrementCounter,
                  tooltip: 'نقص',
                  backgroundColor: Colors.red, // اللون الأحمر لزر النقص
                  child: const Icon(Icons.remove),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
